package org.st.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.st.listener.ProductListener;
import org.st.model.Product;
import org.st.process.ProductItemProcessor;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	//1. Item Reader
	@Bean
	public ItemReader<Product> reader(){
		return new FlatFileItemReader<Product>() {{
			//load file from src(classpath)
			setResource(new ClassPathResource("parts.csv"));
			//reading one line
			setLineMapper(new DefaultLineMapper<Product>() {{
				// one line to multiple values based on symbol ','
				setLineTokenizer(new DelimitedLineTokenizer() {{
					//map variable names to values
					setNames("id","code","cost");
				}});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<Product>() {{
					//select class to create object
					setTargetType(Product.class);
				}});
			}});
		}};
		
	}
	//2. Item Processor
	@Bean
	public ItemProcessor<Product, Product> processor(){
		return new ProductItemProcessor();
	}
	//3. Item Writer
	@Bean
	public ItemWriter<Product> writer(){
		/*JdbcBatchItemWriter<Product> writer=new JdbcBatchItemWriter<>();
		writer.setDataSource(ds());
		writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Product>());
		writer.setSql("insert into prodtab(pid,pcode,pcost,,pdisc,gst) values(:id,:code,:cost,:disc,:gst)");
		*/
		return new JdbcBatchItemWriter<Product>() {{
			//conenct to db
			setDataSource(ds());
			//provide which model class is input
			setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Product>());
			//write insert SQL query
			setSql("insert into prodtab(pid,pcode,pcost,pdisc,gst) values(:id,:code,:cost,:disc,:gst)");
			
		}};
	}
	
	//** DataSource **
	@Bean
	public DataSource ds() {
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost:3306/batch");
		ds.setUsername("root");
		ds.setPassword("root");
		return ds;
	}
	//4. Step Builder Factory
	@Autowired
	private StepBuilderFactory sf;
	//5. configure Step
	@Bean
	public Step stepA() {
		return sf.get("stepA")
				.<Product,Product>chunk(5)
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	}
	
	//6. Job Builder Factory
	@Autowired
	private JobBuilderFactory jf;
	
	//7. configure JOB
	@Bean
	public Job jobA() {
		return jf.get("jobA")
				.incrementer(new RunIdIncrementer())
				.listener(new ProductListener())
				.start(stepA())
				//.next(stepB)
				.build()
				;
	}
	
	
	
	
	
	
}
